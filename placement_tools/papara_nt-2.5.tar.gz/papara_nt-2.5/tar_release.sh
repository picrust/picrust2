tar --exclude 'genassign_blast/*' --exclude 'genassign_blast' --exclude-vcs -c -z -f papara_nt-2.5.tar.gz papara_nt-2.5/
