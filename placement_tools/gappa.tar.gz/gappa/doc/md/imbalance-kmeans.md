## Description

Imbalance k-means has almost the same usage as [Phylogenetic k-means](../wiki/Subcommand:-phylogenetic-kmeans). See there for details. The difference is in the distance measure being used, which is a simple Euclidean distance of the edge imbalances of the samples, instead of using the more involved Phylogenetic KR distance between samples.
