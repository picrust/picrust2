Iris Data Set
=============

Obtained from https://archive.ics.uci.edu/ml/datasets/Iris
Statistics calculated according to http://sebastianraschka.com/Articles/2015_pca_in_3_steps.html
