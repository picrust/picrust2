Json Test Files
===============

Obtained from [pplacer](http://matsen.fhcrc.org/pplacer/) by Eric Matsen.
Original files published under GPL v3 at https://github.com/matsen/pplacer

The "fail" files starting with an underscore are currently excluded from our tests,
because we do not figure it necessary to fail in the cases presented there.
This is not strictly in accordance with the JSON standard, so we might change behaviour
later and include those tests as well.
