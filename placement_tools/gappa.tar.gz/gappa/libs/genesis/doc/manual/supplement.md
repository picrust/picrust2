Supplement {#supplement}
===========

 * @subpage supplement_build_process details for troubleshooting and for those who want to contribute
   to Genesis.
 * @subpage supplement_acknowledgements for saying Thanks and for the dependencies of Genesis.
 * @subpage supplement_license for the full GNU GPL v3 license text.

<!--
Link to the @subpage citelist Bibliography.

@page citelist Bibliography

List of cited references.
-->
