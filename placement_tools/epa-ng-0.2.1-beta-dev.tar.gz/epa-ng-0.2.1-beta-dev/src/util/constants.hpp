#pragma once

// constexpr unsigned int STATES = 4;
// constexpr unsigned int RATE_CATS = 4;

// constexpr unsigned int TINY_PROXIMAL_CLV_INDEX = 0;
// constexpr unsigned int TINY_DISTAL_CLV_INDEX = 1;
// constexpr unsigned int TINY_NEW_TIP_CLV_INDEX = 2;
// constexpr unsigned int TINY_INNER_CLV_INDEX = 3;
// constexpr unsigned int TINY_NUM_OPS = 1;

#define DEFAULT_BRANCH_LENGTH -log(0.9)
// constexpr double DEFAULT_BRANCH_LENGTH = 0.9;
